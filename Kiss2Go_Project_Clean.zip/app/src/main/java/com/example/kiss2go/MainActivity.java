package com.example.kiss2go;

public class MainActivity {}